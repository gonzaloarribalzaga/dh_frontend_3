function Faq() {
  return (
    <div>
      <h1>Faq</h1>
    </div>
  );
}

export default Faq;